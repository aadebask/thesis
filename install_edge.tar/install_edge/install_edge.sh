#! /bin/bash

token="3925f88a84b6fbc2be2096618543fd1ecff00fc061e9631199677961940967fa.eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3MTU0MDQ0ODl9.YdV4yWG_YGX-YLfPLCp8JhXTPrE4h6yGyGuw1A7BvYI"

# Pre-requisites for installing container runtime
echo "Setting Kernel parameter for ipv4 packet forwarding"
cat <<EOF | tee /etc/sysctl.d/k8s.conf
net.ipv4.ip_forward = 1
EOF
sysctl --system

# Installing container runtime interface plugin - containerd
echo "Installing containerd as the container runtime"
apt-get install containerd
mkdir -p /etc/containerd
cp config.toml /etc/containerd/config.toml
systemctl restart containerd

# Installing edgecore service
echo "Installing edgecore service"
sed -i -e "s|token: .*|token: ${token}|g" edgecore.yaml
mkdir -p /etc/kubeedge/config
cp edgecore.yaml /etc/kubeedge/config
cd /opt
wget https://github.com/kubeedge/kubeedge/releases/download/v1.14.5/kubeedge-v1.14.5-linux-amd64.tar.gz
tar -zxvf kubeedge-v1.14.5-linux-amd64.tar.gz
cp kubeedge-v1.14.5-linux-amd64/edge/edgecore /usr/local/bin/edgecore
cat <<EOF > /etc/systemd/system/edgecore.service
[Unit]
Description=edgecore.service

[Service]
Type=Simple
ExecStart=/usr/local/bin/edgecore
Restart=always
RestartSec=10
Environment=DEPLOY_MQTT_CONTAINER=TRUE
KillMode=process

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now edgecore
systemctl start edgecore
